# La sécurité et l'Informatique par Abdelkader Osmani 

A Pen created on CodePen.

Original URL: [https://codepen.io/Kader-the-animator/pen/wBzypqZ](https://codepen.io/Kader-the-animator/pen/wBzypqZ).

